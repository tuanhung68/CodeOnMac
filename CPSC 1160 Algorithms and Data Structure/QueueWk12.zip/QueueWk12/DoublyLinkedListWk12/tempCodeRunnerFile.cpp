
    cout << "The initial queue: ";
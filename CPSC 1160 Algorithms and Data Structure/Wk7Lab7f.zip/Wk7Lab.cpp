#include <iostream>
#include "DynamicArray.h"

using namespace std;

int main(){
    DynamicArray* k = new DynamicArray(10,0,9);

    k->Show();

    


    return 0;
}

    for(int j = 1; j <= NUMBER_OF_LOCKER; j++
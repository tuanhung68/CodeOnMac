#include <cstdlib>
#include <ctime>
#include <iostream>

#ifndef DYNAMICARRAY_H
#define DYNAMICARRAY_H

using namespace std;

class DynamicArray{
public:
    int size;
private:
    int* array;

public:
    // constructors
    // default constructor
    DynamicArray(){
        size = 0;
        array = nullptr;
    }

    // defined constructor, takes parameters / arguments
    DynamicArray(int n){
        // set n to size
        // allocate memory for n integers and set it to array
        // each element has value 0
        size = n;
        array = new int[size];
        for(int i = 0; i < size; i++){
            array[i] = 0;
        }
    }

    DynamicArray(int n, int min, int max){
        // set n to size
        // allocate memory for array with size elements
        // each element is a random integer between min and max (both inclusive)
        srand(time(0));

        size = n;
        array = new int[size];
        for(int i = 0; i < size; i++){
            array[i] = GenerateRandom(min, max);
        }
    }

    // destructor
    ~DynamicArray(){
        if(array){
            delete[] array;
            array = nullptr; 
        }      
    }

    void Show(){
        // displays contents of array on a line
        for(int i = 0; i < size; i++){
            cout << array[i] << " ";
        }
        cout << endl;
    }
public:
//private:
// private methods are for class maintenance purposes (used inside the class' body)
    int GenerateRandom(int min, int max){
        // returns a random integer between min and max (both inclusive)
        int random = rand()%(max-min+1) + min;
        return random;
    }
//  week7's homework
    bool ValidateIndex(int index){
       if(index < 0 || index >= size){
            cout << "This is an invalid index. Exit!" << endl;
            return false;
        }
         //int random = GenerateRandom(0, size - 1);
        cout << "The random value is " << GenerateRandom(0, 9) << endl; 
        return true;
        
    }
    /** 1)
     * @brief add an item at an arbitrary index
     * 
     * @param item 
     * @param index 
     */
    void Add(int item, int index){
        if(ValidateIndex(index) == false){
            return;
        }
        size += 1;
        for(int i = size - 1; i > index; i--){
            array[i] = array[i - 1];
        }
        array[index] = item;
    }
    void AddFirst(int item){
        size += 1;
        for(int i = size - 1; i >= 1; i--){
            array[i] = array[i - 1];
        }
        array[0] = item;
    }
    void AddLast(int item){
        size += 1;
        array[size - 1] = item;
    }
    void Add(int index, int *newItems, int newItemsSize){
        if(ValidateIndex(index) == false){
            return;
        }
        newItems = new int[newItemsSize];
        cout << "The items of the new array are: ";
        for(int i = 0; i < newItemsSize; i++){
            newItems[i] = GenerateRandom(0, 9);
            
        }
        
        cout << endl;
        int oldSize = size;
        size += newItemsSize;
        for(int i = size - 1, j = 0; i >= index + newItemsSize; i--, j++){
            array[i] = array[oldSize - j - 1];
            array[oldSize - j - 1] = 0;
        }
        Show();
        for(int i = 0; i < newItemsSize; i++){
            cout << newItems[i] << " ";
        }
        cout << endl;
        for(int i = index; i < index + newItemsSize; i++){
            // i - index = 0, 1, 2, 3, 4, 5 get value from index 0 to 5
            array[i] = newItems[i - index];
            cout << i - index << " "<< newItems[i - index] << endl;
        }

        
    }
    int Remove(int index){
        if(ValidateIndex(index) == false){
            return -1;
        }
        int removedItem = array[index];
        for(int i = index + 1; i < size; i++){
            array[i - 1] = array[i];
        }
        size -= 1;
        return removedItem;
    }
    int RemoveFirst(){
        int removedItem = array[0];
        for(int i = 1; i < size; i++){
            array[i - 1] = array[i];
        }
        size -= 1;
        return removedItem;
    }
    int RemoveLast(){
        size -= 1;
        return array[size - 1];
    }
    void Remove(int index1, int index2){
        cout << "The value at index " << index1 << " is " << array[index1] << endl;
        cout << "The value at index " << index2 << " is " << array[index2] << endl;
        if((ValidateIndex(index1) || ValidateIndex(index2)) == false && 
        index1 > index2){
            return;
        }
        int random = GenerateRandom(0, 10);
        cout << "The random value is " << random << endl;
        // Removes all items between index1 and index2(both inclusive)
        cout << "Items will be removed are: ";
        for(int i = index1; i <= index2; i++){
            cout << array[i] << " ";
        }
        cout << endl;
        for(int i = 0; i < size - index2 - 1 ; i++){
            array[index1 + i] = array[index2 + i + 1];
        }


        size -= (index2 - index1 + 1); 
    }
};

#endif

